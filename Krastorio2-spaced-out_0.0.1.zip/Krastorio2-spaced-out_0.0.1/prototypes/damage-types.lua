data:extend({
  {
    type = "damage-type",
    name = "kr-explosion", --special damage for turrets
  },
  {
    type = "damage-type",
    name = "kr-radioactive",
  },
})
