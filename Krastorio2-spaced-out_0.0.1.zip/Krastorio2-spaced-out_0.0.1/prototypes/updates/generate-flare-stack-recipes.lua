require("prototypes.libraries.flare-stack").auto_generate()
