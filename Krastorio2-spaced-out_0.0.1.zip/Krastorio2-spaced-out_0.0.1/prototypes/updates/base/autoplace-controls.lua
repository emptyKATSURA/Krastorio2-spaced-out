data.raw["autoplace-control"]["enemy-base"].can_be_disabled = false
