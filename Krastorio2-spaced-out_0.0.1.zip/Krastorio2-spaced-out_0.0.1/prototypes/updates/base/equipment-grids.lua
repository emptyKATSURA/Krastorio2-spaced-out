data.raw["equipment-grid"]["large-equipment-grid"].height = 8
data.raw["equipment-grid"]["large-equipment-grid"].width = 8
data.raw["equipment-grid"]["medium-equipment-grid"].height = 6
data.raw["equipment-grid"]["medium-equipment-grid"].width = 6
data.raw["equipment-grid"]["small-equipment-grid"].height = 4
data.raw["equipment-grid"]["small-equipment-grid"].width = 4
