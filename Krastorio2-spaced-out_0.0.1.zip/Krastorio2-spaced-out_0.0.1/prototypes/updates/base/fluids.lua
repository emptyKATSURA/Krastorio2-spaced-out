data.raw.fluid["petroleum-gas"].emissions_multiplier = 1.25
data.raw.fluid["petroleum-gas"].fuel_value = "900kJ"

data.raw.fluid["steam"].heat_capacity = "0.5kJ"

data.raw.fluid["sulfuric-acid"].heat_capacity = "0.25kJ"

data.raw.fluid["water"].heat_capacity = "0.5kJ"
