data:extend({
  { type = "fuel-category", name = "kr-antimatter-fuel" },
  { type = "fuel-category", name = "kr-fusion-fuel" },
  { type = "fuel-category", name = "kr-vehicle-fuel" },
})
