data:extend({
  { type = "equipment-category", name = "kr-vehicle" },
  { type = "equipment-category", name = "kr-vehicle-motor" },
  { type = "equipment-category", name = "kr-vehicle-roboport" },
})
