data:extend({
  { type = "resource-category", name = "kr-quarry" },
  { type = "resource-category", name = "kr-oil" },
})
