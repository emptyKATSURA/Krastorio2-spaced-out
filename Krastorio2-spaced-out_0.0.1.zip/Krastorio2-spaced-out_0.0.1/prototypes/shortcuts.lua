data:extend({
  {
    type = "shortcut",
    name = "kr-jackhammer",
    icon = "__Krastorio2Assets__/icons/shortcuts/jackhammer.png",
    small_icon = "__Krastorio2Assets__/icons/shortcuts/jackhammer.png",
    action = "spawn-item",
    item_to_spawn = "kr-jackhammer",
    associated_control_input = "kr-jackhammer",
    technology_to_unlock = "concrete",
  },
})
