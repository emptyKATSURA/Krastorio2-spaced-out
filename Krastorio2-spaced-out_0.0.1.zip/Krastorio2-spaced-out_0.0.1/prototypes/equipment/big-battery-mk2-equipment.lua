data:extend({
  {
    type = "recipe",
    name = "kr-big-battery-mk2-equipment",
    energy_required = 30,
    enabled = false,
    ingredients = {
      { type = "item", name = "kr-big-battery-equipment", amount = 2 },
      { type = "item", name = "steel-plate", amount = 4 },
      { type = "item", name = "advanced-circuit", amount = 2 },
    },
    results = { { type = "item", name = "kr-big-battery-mk2-equipment", amount = 1 } },
  },
  {
    type = "item",
    name = "kr-big-battery-mk2-equipment",
    icons = {
      { icon = "__Krastorio2Assets__/icons/equipment/big-battery-mk2-equipment.png" },
      { icon = "__Krastorio2Assets__/icons/equipment/tier-2.png" },
    },
    pictures = {
      layers = {
        {
          filename = "__Krastorio2Assets__/icons/equipment/big-battery-mk2-equipment.png",
          size = 64,
          scale = 0.5,
        },
        {
          filename = "__Krastorio2Assets__/icons/equipment/big-battery-equipment-light.png",
          size = 64,
          scale = 0.5,
          draw_as_light = true,
          flags = { "light" },
        },
      },
    },
    place_as_equipment_result = "kr-big-battery-mk2-equipment",
    subgroup = "equipment",
    order = "b2[battery]-b4[battery-equipment]",
    stack_size = 20,
  },
  {
    type = "battery-equipment",
    name = "kr-big-battery-mk2-equipment",
    sprite = {
      filename = "__Krastorio2Assets__/equipment/big-battery-mk2-equipment.png",
      width = 128,
      height = 128,
      priority = "medium",
      scale = 0.5,
    },
    shape = {
      width = 2,
      height = 2,
      type = "full",
    },
    energy_source = {
      type = "electric",
      buffer_capacity = "75MJ",
      input_flow_limit = "1.5MW",
      output_flow_limit = "2MW",
      usage_priority = "tertiary",
    },
    categories = { "armor", "kr-vehicle" },
  },
})
